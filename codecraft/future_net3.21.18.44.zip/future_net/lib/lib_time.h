﻿#ifndef __LIB_TIME_H__
#define __LIB_TIME_H__


extern void print_time(const char *heads);//打印时间。入参为打印信息头

#endif
